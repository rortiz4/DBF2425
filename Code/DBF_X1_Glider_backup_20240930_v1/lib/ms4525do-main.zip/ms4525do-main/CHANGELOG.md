# Changelog

## v1.1.3
- Updated core to v3.1.3

## v1.1.2
- Updated core to v3.1.2

## v1.1.1
- Updated core to support MMOD

## v1.1.0
- Removed dependency on Units library

## v1.0.0
- Initial commit
